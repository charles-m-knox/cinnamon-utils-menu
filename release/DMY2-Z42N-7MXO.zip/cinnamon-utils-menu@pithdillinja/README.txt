Extract folder 
	cinnamon-utils-menu@pithdillinja 
to 
	~/.local/share/cinnamon/applets/

Open Cinnamon Settings, navigate to Applets, and find the new applet there. You may have to restart cinnamon (ALT+F2, then type in r and press enter to restart via command line) to see it.
